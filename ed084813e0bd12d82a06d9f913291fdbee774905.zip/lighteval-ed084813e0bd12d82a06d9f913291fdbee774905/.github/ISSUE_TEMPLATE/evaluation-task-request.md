---
name: Evaluation/task request
about: Suggest a new evaluation you want us to add
title: "[EVAL]"
labels: new task
assignees: ''

---

## Evaluation short description
- Why is this evaluation interesting?
- How used is it in the community?

## Evaluation metadata
Provide all available
- Paper url:
- Github url:
- Dataset url:
